/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.interescompuestonooptimizado;
import java.util.Scanner;

/**
 *
 * @author mpuebla
 */
public class InteresCompuestoNoOptimizado {

   public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Ingrese el capital inicial: ");
        double capital = input.nextDouble();
        
        System.out.print("Ingrese la tasa de interés anual (en porcentaje): ");
        double tasaInteres = input.nextDouble();
        
        System.out.print("Ingrese el número de años: ");
        int anios = input.nextInt();
        
        System.out.print("Ingrese la cantidad de veces que se capitaliza por año: ");
        int capitalizacion = input.nextInt();
        
        double tasaDecimal = tasaInteres / 100;
        double monto = capital * Math.pow(1 + (tasaDecimal / capitalizacion), capitalizacion * anios);
        
        System.out.printf("El monto total después de %d años es: %.2f%n", anios, monto);
        
        input.close();
    }
}
