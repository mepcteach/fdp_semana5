/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.declaracionvariales;

/**
 *
 * @author mpuebla
 */
 
import java.util.Scanner;


public class DeclaracionVariales {

    // Variables globales: accesibles por todas las funciones dentro de la clase.
    
    // 'input' es una variable global para manejar la entrada de datos del usuario en todo el programa.
    static Scanner input = new Scanner(System.in);
    
    // 'precioInicial' es una variable global que almacena el precio inicial de la vivienda.
    static double precioInicial=0;
    
    // 'tasaInteres' es una variable global que almacena la tasa de interés anual.
    static double tasaInteres;

    // 'aniosPlazo' es una variable global que almacena el número de años de plazo para el cálculo.
    static int aniosPlazo;

    public static void main(String[] args) {
        // Llamada a las funciones para obtener las entradas del usuario y validarlas.
        obtenerDatos();

        // Variable local: 'precioFinal' almacena el resultado del cálculo final.
        double precioFinal = calcularPrecioFinal(precioInicial, tasaInteres, aniosPlazo);

        // Salida final del resultado.
        System.out.printf("El precio final de la vivienda después de %d años es: %.2f%n", aniosPlazo, precioFinal);

        input.close(); // Cierra el recurso Scanner para evitar fugas de recursos.
    }

    // Función para obtener y validar datos del usuario.
    public static void obtenerDatos() {
        // Asigna el valor validado a la variable global 'precioInicial'
        precioInicial = obtenerPrecioInicial();
        // Asigna el valor validado a la variable global 'tasaInteres'
        tasaInteres = obtenerTasaInteres();
        // Asigna el valor validado a la variable global 'aniosPlazo'
        aniosPlazo = obtenerAniosPlazo();
    }

    // Función que calcula el precio final de la vivienda.
    public static double calcularPrecioFinal(double precioInicial, double tasaInteres, int aniosPlazo) {
        // Constante local: usada para calcular el factor de crecimiento (base de la fórmula).
        final double FACTOR = 1 + (tasaInteres / 100);

        // Calcula y retorna el precio final de la vivienda usando el factor de crecimiento.
        return precioInicial * Math.pow(FACTOR, aniosPlazo);
    }

    // Funciones auxiliares para obtener y validar datos.
    public static double obtenerPrecioInicial() {
        double precio = 0;
        while (precio <= 0) {
            System.out.print("Ingrese el precio inicial de la vivienda (mayor a 0): ");
            precio = input.nextDouble();
            if (precio <= 0) {
                System.out.println("El precio debe ser un valor positivo.");
            }
        }
        return precio;
    }

    public static double obtenerTasaInteres() {
        double tasa = -1;
        while (tasa < 0) {
            System.out.print("Ingrese la tasa de interés anual (mayor o igual a 0): ");
            tasa = input.nextDouble();
            if (tasa < 0) {
                System.out.println("La tasa de interés no puede ser negativa.");
            }
        }
        return tasa;
    }

    public static int obtenerAniosPlazo() {
        int anios = 0;
        while (anios <= 0) {
            System.out.print("Ingrese el número de años de plazo (mayor a 0): ");
            anios = input.nextInt();
            if (anios <= 0) {
                System.out.println("El plazo debe ser un valor entero positivo.");
            }
        }
        return anios;
    }
}
