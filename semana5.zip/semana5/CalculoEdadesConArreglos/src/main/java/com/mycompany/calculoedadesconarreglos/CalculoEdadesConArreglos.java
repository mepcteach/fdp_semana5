/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculoedadesconarreglos;

/**
 *
 * @author mpuebla
 */
import java.time.LocalDate; // Importa la clase LocalDate para manejar fechas
import java.time.Period;    // Importa la clase Period para calcular diferencias entre fechas

public class CalculoEdadesConArreglos {

    // Estructura que representa una persona
    static class Persona {
        String nombre;          // Nombre de la persona (String)
        LocalDate fechaNacimiento; // Fecha de nacimiento (LocalDate)
        float altura;          // Altura en metros (float)
        boolean esActivo;      // Estado activo de la persona (boolean)
        byte edadEnMeses;      // Edad en meses (byte)

        // Constructor de la clase Persona
        Persona(String nombre, LocalDate fechaNacimiento, float altura, boolean esActivo) {
            this.nombre = nombre;
            this.fechaNacimiento = fechaNacimiento;
            this.altura = altura;
            this.esActivo = esActivo;
            this.edadEnMeses = calcularEdadEnMeses(fechaNacimiento); // Inicializa la edad en meses
        }

        // Método para calcular la edad en meses
        private byte calcularEdadEnMeses(LocalDate fechaNacimiento) {
            // Calcular la diferencia en meses
            Period periodo = Period.between(fechaNacimiento, LocalDate.now());
            int edadEnMeses = periodo.getYears() * 12 + periodo.getMonths(); // Total de meses
            return (byte) edadEnMeses; // Convertir a byte
        }
    }

    // Variables globales: Arreglo de personas
    static Persona[] personas = {
        new Persona("Juan", LocalDate.of(1990, 5, 15), 1.75f, true),   // Persona 1
        new Persona("María", LocalDate.of(1985, 8, 22), 1.62f, false),  // Persona 2
        new Persona("Carlos", LocalDate.of(2000, 12, 1), 1.80f, true),  // Persona 3
        new Persona("Ana", LocalDate.of(1995, 3, 30), 1.70f, true)     // Persona 4
    };

    public static void main(String[] args) {
        // Calcular y mostrar las edades de cada persona
        calcularYMostrarEdades();
    }

    // Función que calcula y muestra las edades de las personas
    public static void calcularYMostrarEdades() {
        // Bucle para recorrer el arreglo de personas
        for (Persona persona : personas) { // Variable local `persona` de tipo Persona en cada iteración
            // Llamada a la función que calcula la edad en años
            int edad = calcularEdad(persona.fechaNacimiento); // Variable local `edad` de tipo int que almacena la edad en años
            // Mostrar el nombre, edad y altura de la persona
            System.out.println("La edad de " + persona.nombre + " es: " + edad + " años");
            System.out.println("Altura: " + persona.altura + " metros");
            System.out.println("Estado activo: " + persona.esActivo);
            System.out.println("Edad en meses: " + persona.edadEnMeses + " meses");
            System.out.println();
        }
    }

    // Función para calcular la edad de una persona basada en su fecha de nacimiento
    public static int calcularEdad(LocalDate fechaNacimiento) {
        // Variable local `fechaActual` de tipo LocalDate que almacena la fecha actual del sistema
        LocalDate fechaActual = LocalDate.now();
        // Se calcula la diferencia de años entre la fecha de nacimiento y la fecha actual utilizando Period
        return Period.between(fechaNacimiento, fechaActual).getYears(); // Retorna la edad calculada en años
    }
}

