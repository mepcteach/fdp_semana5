/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrovacunas;

/**
 *
 * @author mpuebla
 */
import java.util.Scanner;

public class RegistroVacunas {
    public static void main(String[] args) {
        // Definir el número de personas
        final int NUM_PERSONAS = 5;
        
        // Crear un array para almacenar los nombres de las personas
        String[] nombres = new String[NUM_PERSONAS];
        // Crear un array para almacenar el estado de vacunación
        boolean[] vacunado = new boolean[NUM_PERSONAS];
        
        // Crear un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        
        // Registrar los nombres de las personas
        for (int i = 0; i < NUM_PERSONAS; i++) {
            System.out.println("Ingresa el nombre de la persona " + (i + 1) + ": ");
            nombres[i] = scanner.nextLine().trim();
        }
        
        // Registro de vacunas para cada persona
        for (int i = 0; i < NUM_PERSONAS; i++) {
            System.out.println("¿" + nombres[i] + " ha sido vacunado? (Sí/No): ");
            String respuesta = scanner.nextLine().trim().toLowerCase();
            
            // Validar la entrada del usuario
            if (respuesta.equals("sí") || respuesta.equals("si")) {
                vacunado[i] = true;
            } else if (respuesta.equals("no")) {
                vacunado[i] = false;
            } else {
                System.out.println("Respuesta inválida. Por favor ingresa 'Sí' o 'No'.");
                i--; // Repetir la iteración actual
            }
        }
        
        // Verificar el estado de vacunación y mostrar resultados
        boolean todosVacunados = true;
        for (int i = 0; i < NUM_PERSONAS; i++) {
            if (vacunado[i]) {
                System.out.println(nombres[i] + " ha sido vacunado.");
            } else {
                System.out.println(nombres[i] + " no ha sido vacunado.");
                todosVacunados = false;
            }
        }
        
        // Mensaje final
        if (todosVacunados) {
            System.out.println("¡Todas las personas han sido vacunadas correctamente!");
        } else {
            System.out.println("Algunas personas no han sido vacunadas.");
        }
        
        // Cerrar el scanner
        scanner.close();
    }
}
