/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.interescompuestooptimizado;

/**
 *
 * @author mpuebla
 */
import java.util.Scanner;

public class InteresCompuestoOptimizado {

// Función para calcular el interés compuesto
    public static double calcularInteresCompuesto(double capital, double tasaInteres, int anios, int capitalizacion) {
        final double tasaDecimal = tasaInteres / 100;  // Convierte la tasa de porcentaje a decimal solo una vez
        double factor = 1 + (tasaDecimal / capitalizacion);  // Calcula el factor una sola vez
        return capital * Math.pow(factor, capitalizacion * anios);  // Reutiliza el cálculo de factor
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Entradas de datos
        System.out.print("Ingrese el capital inicial: ");
        double capital = input.nextDouble();
        
        System.out.print("Ingrese la tasa de interés anual (en porcentaje): ");
        double tasaInteres = input.nextDouble();
        
        System.out.print("Ingrese el número de años: ");
        int anios = input.nextInt();
        
        System.out.print("Ingrese la cantidad de veces que se capitaliza por año: ");
        int capitalizacion = input.nextInt();
        
        // Cálculo del interés compuesto con método separado
        double monto = calcularInteresCompuesto(capital, tasaInteres, anios, capitalizacion);
        
        // Salida del resultado
        System.out.printf("El monto total después de %d años es: %.2f%n", anios, monto);
        
        input.close();
    }
}
