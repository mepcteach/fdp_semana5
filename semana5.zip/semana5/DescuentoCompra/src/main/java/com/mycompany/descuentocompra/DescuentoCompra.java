/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.descuentocompra;

/**
 *
 * @author mpuebla
 */
import java.util.Scanner;

public class DescuentoCompra {

    // Scanner global para manejar la entrada del usuario
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        // Llamada a la función para procesar los descuentos
        procesarDescuentos();

        // Cerrar el Scanner
        input.close();
    }

    // Función que procesa los descuentos de una compra
    public static void procesarDescuentos() {
        // Inicialización de variables locales
        double precioTotal = 0;
        double descuentoTotal = 0;
        int cantidadProductos = 0;

        // Validación de la cantidad de productos
        cantidadProductos = obtenerCantidadProductos();

        // Bucle para aplicar descuentos por cada producto
        for (int i = 1; i <= cantidadProductos; i++) {
            System.out.printf("Ingrese el precio del producto %d: ", i);
            double precioProducto = validarEntradaNumerica();

            // Aplicar descuento al producto
            double descuentoProducto = aplicarDescuento(precioProducto);
            descuentoTotal += descuentoProducto;
            precioTotal += precioProducto - descuentoProducto;

            System.out.printf("Descuento aplicado al producto %d: %.2f\n", i, descuentoProducto);
        }

        // Mostrar resultados finales
        System.out.printf("El precio total con descuentos es: %.2f\n", precioTotal);
        System.out.printf("El descuento total aplicado es: %.2f\n", descuentoTotal);
    }

    // Función para obtener la cantidad de productos a comprar
    public static int obtenerCantidadProductos() {
        System.out.print("Ingrese la cantidad de productos a comprar: ");
        int cantidad = (int) validarEntradaNumerica();

        // Validar que la cantidad de productos sea mayor a 0
        while (cantidad <= 0) {
            System.out.println("La cantidad de productos debe ser mayor a 0. Inténtelo de nuevo.");
            cantidad = (int) validarEntradaNumerica();
        }
        return cantidad;
    }

    // Función que aplica un descuento basado en el precio del producto
    public static double aplicarDescuento(double precio) {
        double descuento = 0;

        // Descuento del 10% para productos con precio mayor a 100
        if (precio > 100) {
            descuento = precio * 0.10;
        } else if (precio > 50) {
            descuento = precio * 0.05; // 5% de descuento para productos entre 50 y 100
        }

        return descuento;
    }

    // Función que valida que la entrada sea numérica y devuelve el número
    public static double validarEntradaNumerica() {
        while (!input.hasNextDouble()) {
            System.out.println("Entrada inválida. Por favor, ingrese un número válido.");
            input.next();  // Descartar la entrada no válida
        }
        return input.nextDouble();
    }
}
